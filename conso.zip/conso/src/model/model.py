import pandas as pd
import numpy 


df = pd.read_csv('../../src/data/fusion.csv', sep=";")

print(df)
energy = []
energy = df['Energy'].tolist
t = df['Energy']
print (t)

for i in t :
    x = t[i+1] - t[i]
    print(x)


