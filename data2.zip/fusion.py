import csv;

a= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-7-4_5.csv")
b= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-7-4_6.csv")
c= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-7-4_7.csv")
d= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-7-4_8.csv")
e= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-12-4_5.csv")
f= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-12-4_6.csv")
g= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-12-4_7.csv")
h= open (r"C:\Users\emili\Google Drive\cours\SAE15\data\raw\energy-125-12-4_8.csv")


with open(r"C:\Users\emili\Google Drive\cours\SAE15\data2.csv",'w',newline='') as fichiercsv:
    writer=csv.writer(fichiercsv)
    writer.writerow(a)
    writer.writerow(b)
    writer.writerow(c)
    writer.writerow(d)
    writer.writerow(e)
    writer.writerow(f)
    writer.writerow(g)
    writer.writerow(h)
j= open('data2.csv')
myReader = csv.reader(j)
for i in myReader:
    print(i)