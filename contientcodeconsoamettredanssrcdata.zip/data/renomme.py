# -*- coding: utf-8 -*-
import csv;
import pandas as pd;

df = pd.read_csv('../../src/data/fusion.csv', sep=",")
