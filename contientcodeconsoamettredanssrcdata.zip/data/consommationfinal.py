# -*- coding: utf-8 -*-
import pandas as pd;

data1 = pd.read_csv ('../../data/raw/energy-125-7-4_5.csv', sep=",")
data2 = pd.read_csv ('../../data/raw/energy-125-7-4_6.csv', sep=',')
data3 = pd.read_csv ('../../data/raw/energy-125-7-4_7.csv', sep=',')
data4 = pd.read_csv ('../../data/raw/energy-125-7-4_8.csv', sep=',')
data5 = pd.read_csv ('../../data/raw/energy-125-12-4_5.csv', sep=',')
data6 = pd.read_csv ('../../data/raw/energy-125-12-4_6.csv', sep=',')
data7 = pd.read_csv ('../../data/raw/energy-125-12-4_7.csv', sep=',')
data8 = pd.read_csv ('../../data/raw/energy-125-12-4_8.csv', sep=',')

un = 0
un = data1.iloc[-1,3]
deux = data2.iloc[-1,3]
trois = data3.iloc[-1,3]
quatre = data4.iloc[-1,3]
cinq = data5.iloc[-1,3]
six = data6.iloc[-1,3]
sept = data7.iloc[-1,3]
huit = data8.iloc[-1,3]
all_nb = [un,deux,trois,quatre,cinq,six,sept,huit]

for i in all_nb:
    for item in all_nb:
        x = un - item
        print("la différence entre", i," observation et la", item, " est de:", x)



