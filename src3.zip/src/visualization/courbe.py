# -*- coding: utf-8 -*-
"""
Created on Thu Jan 27 15:48:51 2022

@author: e2100503
"""

import pandas as pd
import csv
import matplotlib.pyplot as plt

x = []
y = []

with open('../../src/data/fusion.csv', "r") as csvfile:
    plots = csv.reader(csvfile, delimiter=';')
    for row in plots:
        x.append(str(row[1]))
        y.append(str(row[4]))
        
df = pd.read_csv('../../src/data/fusion.csv')

l=[]

for i in range(len(x)):
    if x[i]=="Timestamp":
        l.append(y[i])
        
y=[i for i in range(len(l))]

plt.xlabel('Timestamp', fontsize=10)
plt.ylabel('Energy', fontsize=10)
plt.title('Energie total consommée en fonction du facteur étalement et du taux de redondance des bits')
plt.plot(y,l)

plt.show()

