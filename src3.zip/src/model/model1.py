import pandas as pd
import csv


df = pd.read_csv('../../src/data/fusion.csv', sep=";")

print(df)
df.sort_values('Current')


def ComputeMean(column):
    f = open("../../src/data/fusion.csv","r")
    mean = 0
    average=0.0
    Sum=0
    keys = ["Indices",'Timestamp','Current','Voltage','Energy','UART']
    row_count = 0
    for row in f:
        for column in row.split(';'):
            n=float("Current")
            Sum += n
        row_count += 1
    average = Sum / len("Current")
    f.close()
    return 'The average is:', average
    return mean













    #with open("../../src/data/fusion.csv",'r') as file:
     #   reader = csv.reader(file)
      #  for i in reader:
       #         i=i[0].split(";")
        #        if list(i)[keys.index(column)]=="":
         #           Sum += i
          #          average = Sum / len(column)
          #      return 'The average is:', average
    



print(ComputeMean("Current"))
#def ComputeMedian:
   # median = 0
    #return (median)    
    