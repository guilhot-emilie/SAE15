 
#import pandas as pd

import numpy as np
import csv

readdata = csv.reader(open('../../src/data/fusion.csv', 'r'))
data = []

for row in readdata:
  data.append(row)

#incase you have a header/title in the first row of your csv file, do the next line else skip it
data.pop(0) 

q1 = []  

for i in range(len(data)):
  q1.append(int(data[i][3]))

print ('Mean of your_column_number :            ', (np.mean(q1)))

#def ComputeMedian:
    #median = 0
    #return (median)    
    
    
