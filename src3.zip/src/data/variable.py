# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 20:26:39 2022

@author: emcri
"""
import pandas as pd

import csv


df = pd.read_csv('fusion.csv')


#pour chaque colonnes
def manquant(column):
    missing=0
    keys = ["Indices",'Timestamp','Current','Voltage','Energy','UART']
    with open("fusion.csv",'r') as file:
        reader = csv.reader(file)
        for i in reader:
            i=i[0].split(";")
            if list(i)[keys.index(column)]=="":
                missing += 1
    return missing


#pour toutes les lignes
def manquant_tout():
    missing=0
    with open("fusion.csv",'r') as file:
        reader = csv.reader(file)
        for i in reader:
            i=i[0].split(";")
            if "" in i:
                missing += 1
    return missing


#pour toutes les données
def donnee_manq():
    missing=0
    with open("fusion.csv",'r') as file:
        reader = csv.reader(file)
        for i in reader:
            i=i[0].split(";")
            if "" in i:
                missing += i.count("")
    return missing



print("question2")

print(manquant("Timestamp"))
pourcent_manquant = manquant("Timestamp") * 100 / 2682781
print(pourcent_manquant)

print(manquant("Current"))
pourcent_manquant = manquant("Current") * 100 / 2682781
print(pourcent_manquant)

print(manquant("Voltage"))
pourcent_manquant = manquant("Voltage") * 100 / 2682781
print(pourcent_manquant)

print(manquant("Energy"))

pourcent_manquant = manquant("Energy") * 100 / 2682781
print(pourcent_manquant)

print(manquant("UART"))
pourcent_manquant = manquant("UART") * 100 / 2682781
print(pourcent_manquant)


print("question 3")
print(manquant_tout())
pourcent_manq = manquant_tout() * 100 / 2682781
print(pourcent_manq)

print(donnee_manq())
pourcent_manq = donnee_manq() * 100 / 2682781
print(pourcent_manq)






