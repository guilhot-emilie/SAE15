import pandas as pd
import csv


df = pd.read_csv('../../src/data/fusion.csv', sep=";")

print(df)
df.sort_values('Current')


def ComputeMean():
    mean = 0
    DataFrame.mean(axis=NoDefault.no_default, skipna=True, level=None, numeric_only=None, **kwargs)
    return (mean)

def ComputeMedian:
    median = 0
    return (median)    
    