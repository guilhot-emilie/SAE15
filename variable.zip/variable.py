# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 20:26:39 2022

@author: emcri
"""
import pandas as pd


df = pd.read_csv('fusion.csv')

#print(df.loc[df['Timestamp']=="",:])
#print(df.loc[df['File Main']=="",:])
#print(df.loc[df['File Main Voltage']=="",:])
#print(df.loc[df['File Main Energy']=="",:])
#print(df.loc[df['File UART']=="",:])

total_value = df.isnull().sum()
percent_missing = df.isnull().sum() * 100 / len(df) 
missing_valuedf = pd.DataFrame({'column_name':df.columns,'percent_missing':percent_missing})
data_frame = sum(df.isnull().any(axis=1))
data_calculated = data_frame * 100 / len(df)

print("exercice2")
print(total_value)
print(round(percent_missing))
print("exercice3")
print(data_frame)
print(round(data_calculated))