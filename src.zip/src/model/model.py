 

def ComputeMean():
    mean = 0
    return (mean)

def ComputeMedian:
    median = 0
    return (median)    
    
    
