# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 08:40:06 2022

@author: emeline
"""
import pandas as pd


data1 = pd.read_csv ('..//..//data//raw//energy-125-7-4_5.csv')
data2 = pd.read_csv ('..//..//data//raw//energy-125-7-4_6.csv')
data3 = pd.read_csv ('..//..//data//raw//energy-125-7-4_7.csv')
data4 = pd.read_csv ('..//..//data//raw//energy-125-7-4_8.csv')
data5 = pd.read_csv ('..//..//data//raw//energy-125-12-4_5.csv')
data6 = pd.read_csv ('..//..//data//raw//energy-125-12-4_6.csv')
data7 = pd.read_csv ('..//..//data//raw//energy-125-12-4_7.csv')
data8 = pd.read_csv ('..//..//data//raw//energy-125-12-4_8.csv')

all_df = [data1, data2, data3, data4, data5, data6, data7, data8]
fusion =  pd.concat(all_df)

print(fusion)

fusion.to_csv('fusion.csv')
